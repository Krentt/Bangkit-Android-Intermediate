package com.dicoding.mystudentdata.helper

enum class SortType {
    ASCENDING,
    DESCENDING,
    RANDOM
}
